import { AddBillForm } from "@/components/add-bill-form"

export default function AddBill() {
  return <AddBillForm />
}
