import { AddTransactionPage } from "@/components/add-transaction-page"

export default function AddTransaction() {
  return <AddTransactionPage />
}
