import { PlanningPage } from "@/components/planning-page"

export default function Planning() {
  return <PlanningPage />
}
