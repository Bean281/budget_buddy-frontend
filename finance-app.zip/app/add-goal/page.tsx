import { AddGoalForm } from "@/components/add-goal-form"

export default function AddGoal() {
  return <AddGoalForm />
}
