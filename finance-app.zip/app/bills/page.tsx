import { BillsPage } from "@/components/bills-page"

export default function Bills() {
  return <BillsPage />
}
