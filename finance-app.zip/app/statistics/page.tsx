import { StatisticsPage } from "@/components/statistics-page"

export default function Statistics() {
  return <StatisticsPage />
}
