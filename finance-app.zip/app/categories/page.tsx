import { CategoryManagementPage } from "@/components/category-management-page"

export default function Categories() {
  return <CategoryManagementPage />
}
