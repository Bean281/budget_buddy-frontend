import { TransactionsPage } from "@/components/transactions-page"

export default function Transactions() {
  return <TransactionsPage />
}
