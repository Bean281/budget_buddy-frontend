import { GoalsPage } from "@/components/goals-page"

export default function Goals() {
  return <GoalsPage />
}
